OpenChargeback — Monthly Close Package
Period: 2025-12

WHAT THIS IS
  A forensic, audit-defensible snapshot of one billing month: the
  original source files, the statements sent to PIs, the journal entry
  export, the proof-of-send email log, and the audit trail. With this
  package in hand, research accounting holds the canonical record and
  the audit liability stays with them.

CONTENTS
  journal.csv        Bulk journal entries (the ERP handoff).
  statements/        Final PDF statements, exactly as emailed to PIs.
  inputs/            Original source files that generated the results,
                     organized by source. (Empty for months imported
                     before input retention was enabled.)
  email-log.csv      Proof of send: when each statement went out.
  audit.csv          Period lifecycle + every charge review action.
  MANIFEST.txt       sha256 of every file above, as delivered.

PROVENANCE / 'SIGNED PACKAGE'
  MANIFEST.txt lists the sha256 of each file in this archive. That
  per-file hash list is the package's signature — verify any file by
  re-hashing it and comparing. The 6-character suffix on this package's
  filename is the last 6 chars of the sha256 of the entire archive,
  making the bundle content-addressable. Re-running the close on the
  same canonical data produces the same hash. A different hash means
  something changed — that is a feature, not a bug.

RETENTION
  Archived input files are kept indefinitely by default. A future
  RETENTION_YEARS setting (-1 = indefinite) is the planned hook for
  policy-based rolloff; until then the archive simply grows.

FUTURE: RESOURCE ALLOCATION
  When resource splitting lands (one resource shared across projects,
  e.g. 75/25), the allocation rules that produced each split will be
  included here so the paper trail explains its own math.
